# House Price Predictor (Gradio + Hugging Face Spaces)

Proyek ini memprediksi harga rumah berdasarkan data fitur sederhana.

## Cara Menjalankan di Lokal
1. Install dependencies:
```bash
pip install -r requirements.txt
```
2. Latih model:
```bash
python train.py
```
3. Jalankan aplikasi Gradio:
```bash
python app.py
```
4. Akses di browser: `http://127.0.0.1:7860`

## Cara Deploy di Hugging Face Spaces
1. Buat akun di [Hugging Face](https://huggingface.co/).
2. Buat Space baru, pilih **Gradio** sebagai SDK.
3. Upload semua file dari folder ini.
4. Klik **Commit** → Aplikasi akan langsung online.
