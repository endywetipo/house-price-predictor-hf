import gradio as gr
import pandas as pd
import joblib

# Load model
model = joblib.load("model/model.pkl")

# Fungsi prediksi
def predict(longitude, latitude, housing_median_age, total_rooms, total_bedrooms, population, households, median_income):
    data = pd.DataFrame([[longitude, latitude, housing_median_age, total_rooms, total_bedrooms, population, households, median_income]],
                        columns=["longitude", "latitude", "housing_median_age", "total_rooms", "total_bedrooms", "population", "households", "median_income"])
    prediction = model.predict(data)[0]
    return f"Prediksi Harga Rumah: ${prediction:,.2f}"

# UI Gradio
iface = gr.Interface(
    fn=predict,
    inputs=[
        gr.Number(label="Longitude"),
        gr.Number(label="Latitude"),
        gr.Number(label="Housing Median Age"),
        gr.Number(label="Total Rooms"),
        gr.Number(label="Total Bedrooms"),
        gr.Number(label="Population"),
        gr.Number(label="Households"),
        gr.Number(label="Median Income"),
    ],
    outputs="text",
    title="House Price Predictor",
    description="Masukkan data rumah untuk memprediksi harga."
)

if __name__ == "__main__":
    iface.launch()